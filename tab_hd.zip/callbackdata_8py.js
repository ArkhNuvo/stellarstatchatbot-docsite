var callbackdata_8py =
[
    [ "callbackdata.UserData", "classcallbackdata_1_1_user_data.html", null ],
    [ "callbackdata.DocInfo", "classcallbackdata_1_1_doc_info.html", null ],
    [ "callbackdata.ColInfo", "classcallbackdata_1_1_col_info.html", null ],
    [ "callbackdata.StatInfo", "classcallbackdata_1_1_stat_info.html", null ]
];