var annotated_dup =
[
    [ "callbackdata", "namespacecallbackdata.html", [
      [ "ColInfo", "classcallbackdata_1_1_col_info.html", null ],
      [ "DocInfo", "classcallbackdata_1_1_doc_info.html", null ],
      [ "StatInfo", "classcallbackdata_1_1_stat_info.html", null ],
      [ "UserData", "classcallbackdata_1_1_user_data.html", null ]
    ] ],
    [ "is_contact", "namespaceis__contact.html", [
      [ "IsTrueContact", "classis__contact_1_1_is_true_contact.html", "classis__contact_1_1_is_true_contact" ]
    ] ],
    [ "settings", "namespacesettings.html", [
      [ "Bots", "classsettings_1_1_bots.html", null ],
      [ "Settings", "classsettings_1_1_settings.html", null ]
    ] ]
];