var main_8py =
[
    [ "start", "main_8py.html#ac6ca7cf4dd99d5de436dfc118ee79381", null ],
    [ "start_bot", "main_8py.html#a6c4a407c897e47c1979a57b72e146d3b", null ],
    [ "stop_bot", "main_8py.html#a1126c7169a767287dec5e4f2adf7ffa7", null ]
];