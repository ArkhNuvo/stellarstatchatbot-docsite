var searchData=
[
  ['file_5fcount_0',['file_count',['../classcallbackdata_1_1_user_data.html#a4fce825bfa41c24ec27b3e96e3412ed4',1,'callbackdata::UserData']]],
  ['folder_5fpath_1',['folder_path',['../classcallbackdata_1_1_user_data.html#a18e1b0bcbcc664ef7b2079c72fdd574f',1,'callbackdata::UserData']]]
];
