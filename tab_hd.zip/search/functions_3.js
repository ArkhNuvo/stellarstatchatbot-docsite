var searchData=
[
  ['description_5fprint_0',['description_print',['../namespacestat.html#a0c91dc07b0ee583a86243d84c7bf64ae',1,'stat']]],
  ['dis_5fplot_5fnum_1',['dis_plot_num',['../namespacestat.html#a1bccaee6d3a19fed94db358389f110bd',1,'stat']]],
  ['doc_5fimport_2',['doc_import',['../namespacestat.html#a1d5eb253ea55d24b57ce66c950b77ecf',1,'stat']]]
];
