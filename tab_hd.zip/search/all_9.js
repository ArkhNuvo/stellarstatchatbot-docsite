var searchData=
[
  ['name_0',['name',['../classcallbackdata_1_1_user_data.html#ab40ffa5ef21020b0b417821d106f0064',1,'callbackdata.UserData.name'],['../classcallbackdata_1_1_doc_info.html#a6c16427d0a6cd079c90040cc7b7a0b8a',1,'callbackdata.DocInfo.name']]]
];
