var searchData=
[
  ['colinfo_0',['ColInfo',['../classcallbackdata_1_1_col_info.html',1,'callbackdata']]]
];
