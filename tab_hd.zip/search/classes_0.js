var searchData=
[
  ['bots_0',['Bots',['../classsettings_1_1_bots.html',1,'settings']]]
];
