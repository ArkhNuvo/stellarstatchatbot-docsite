var searchData=
[
  ['value_5fcounts_5fcount_0',['value_counts_count',['../namespacestat.html#a2567375d8fa334995e4c2fbe9db8da6f',1,'stat']]],
  ['var_5fcount_1',['var_count',['../namespacestat.html#adf927a1aa5222046a1786f17dcf0cdae',1,'stat']]],
  ['violin_5fplot_2',['violin_plot',['../namespacestat.html#a303c07301560fbd07a47202b51f0b3fc',1,'stat']]]
];
