var searchData=
[
  ['type_0',['type',['../classcallbackdata_1_1_col_info.html#a866cf0d709decd4c024e69651386bfc6',1,'callbackdata::ColInfo']]]
];
