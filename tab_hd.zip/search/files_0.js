var searchData=
[
  ['basic_2epy_0',['basic.py',['../basic_8py.html',1,'']]]
];
