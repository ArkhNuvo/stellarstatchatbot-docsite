var searchData=
[
  ['settings_0',['settings',['../namespacesettings.html',1,'']]],
  ['stat_1',['stat',['../namespacestat.html',1,'']]]
];
