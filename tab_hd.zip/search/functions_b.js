var searchData=
[
  ['unique_0',['unique',['../namespacestat.html#a8766509ffb6adccd1e8377fd38dcbef3',1,'stat']]],
  ['unique_5fcount_1',['unique_count',['../namespacestat.html#a24a699a0ac8b5186992f7123c4ce9b7a',1,'stat']]]
];
