var searchData=
[
  ['basic_0',['basic',['../namespacebasic.html',1,'']]],
  ['basic_2epy_1',['basic.py',['../basic_8py.html',1,'']]],
  ['bot_5ftoken_2',['bot_token',['../classsettings_1_1_bots.html#ac82d3fccc339b4382bb5f43f9b39ae50',1,'settings::Bots']]],
  ['bots_3',['Bots',['../classsettings_1_1_bots.html',1,'settings']]],
  ['bots_4',['bots',['../classsettings_1_1_settings.html#a26a38738a8fa2cfe5fd317d0011b252c',1,'settings::Settings']]],
  ['box_5fplot_5',['box_plot',['../namespacestat.html#a4fb3673f082e93094ac221449fd0ed9b',1,'stat']]]
];
