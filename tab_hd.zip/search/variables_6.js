var searchData=
[
  ['settings_0',['settings',['../namespacesettings.html#a4742249a184e489a7b067fdcf88f301d',1,'settings']]],
  ['stat_5foption_1',['stat_option',['../classcallbackdata_1_1_stat_info.html#a8e3fccc435129e777227205c24893548',1,'callbackdata::StatInfo']]]
];
