var searchData=
[
  ['basic_0',['basic',['../namespacebasic.html',1,'']]]
];
