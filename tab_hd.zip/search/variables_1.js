var searchData=
[
  ['bot_5ftoken_0',['bot_token',['../classsettings_1_1_bots.html#ac82d3fccc339b4382bb5f43f9b39ae50',1,'settings::Bots']]],
  ['bots_1',['bots',['../classsettings_1_1_settings.html#a26a38738a8fa2cfe5fd317d0011b252c',1,'settings::Settings']]]
];
