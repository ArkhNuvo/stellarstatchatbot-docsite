var searchData=
[
  ['action_0',['action',['../classcallbackdata_1_1_doc_info.html#addf19d79f098bd2dc5c0f17724e7330c',1,'callbackdata::DocInfo']]],
  ['admin_5fid_1',['admin_id',['../classsettings_1_1_bots.html#aea103044d1005db1037f9db4933d2c49',1,'settings::Bots']]]
];
