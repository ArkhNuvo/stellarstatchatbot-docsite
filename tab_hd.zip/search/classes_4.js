var searchData=
[
  ['settings_0',['Settings',['../classsettings_1_1_settings.html',1,'settings']]],
  ['statinfo_1',['StatInfo',['../classcallbackdata_1_1_stat_info.html',1,'callbackdata']]]
];
