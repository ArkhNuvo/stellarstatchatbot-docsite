var searchData=
[
  ['trim_5fmean_5f10_5fcount_0',['trim_mean_10_count',['../namespacestat.html#a4f397344ed05559211d84b2f3d501cc2',1,'stat']]],
  ['type_1',['type',['../classcallbackdata_1_1_col_info.html#a866cf0d709decd4c024e69651386bfc6',1,'callbackdata::ColInfo']]]
];
