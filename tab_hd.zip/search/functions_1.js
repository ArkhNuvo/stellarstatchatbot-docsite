var searchData=
[
  ['box_5fplot_0',['box_plot',['../namespacestat.html#a4fb3673f082e93094ac221449fd0ed9b',1,'stat']]]
];
