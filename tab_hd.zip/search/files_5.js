var searchData=
[
  ['settings_2epy_0',['settings.py',['../settings_8py.html',1,'']]],
  ['stat_2epy_1',['stat.py',['../stat_8py.html',1,'']]]
];
