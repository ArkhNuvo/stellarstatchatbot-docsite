var searchData=
[
  ['user_5fdata_0',['user_data',['../namespaceuser__data.html',1,'']]]
];
