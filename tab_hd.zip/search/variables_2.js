var searchData=
[
  ['choice_0',['choice',['../classcallbackdata_1_1_doc_info.html#a0fe658dba987fc5ecc0d5fef6ad41f5a',1,'callbackdata::DocInfo']]],
  ['col_5fname_1',['col_name',['../classcallbackdata_1_1_col_info.html#a2b7f0638575f908798cfd640ef6e886a',1,'callbackdata::ColInfo']]]
];
