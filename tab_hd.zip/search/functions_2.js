var searchData=
[
  ['choice_5fcol_5foption_0',['choice_col_option',['../namespacecallback.html#a11165dcace205f02ddfdf0d34e3f946c',1,'callback']]],
  ['choose_5ffile_1',['choose_file',['../namespacebasic.html#a8cfa9a69ddaeb63dc560c79b147f7858',1,'basic']]],
  ['chose_5ffile_5ffrom_5fstorage_2',['chose_file_from_storage',['../namespacecallback.html#a82257516ce42602115dc309fe791f234',1,'callback']]],
  ['collect_5fdoc_5finfo_3',['collect_doc_info',['../namespaceuser__data.html#a9bdb0c96198ae6ad0ab2d6332a96c691',1,'user_data']]],
  ['collect_5fgeneral_5fdata_4',['collect_general_data',['../namespaceuser__data.html#adbaf29cac9edd842b77f435f2e44ae4b',1,'user_data']]],
  ['columns_5fprint_5',['columns_print',['../namespacestat.html#a93d5766c510b7cea592399dd604f6071',1,'stat']]],
  ['count_5fplot_6',['count_plot',['../namespacestat.html#a9507fbccad0d55ad8cbef0f22ff8d4db',1,'stat']]]
];
