var searchData=
[
  ['trim_5fmean_5f10_5fcount_0',['trim_mean_10_count',['../namespacestat.html#a4f397344ed05559211d84b2f3d501cc2',1,'stat']]]
];
