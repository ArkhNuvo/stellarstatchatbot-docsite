var user__data_8py =
[
    [ "collect_doc_info", "user__data_8py.html#a9bdb0c96198ae6ad0ab2d6332a96c691", null ],
    [ "collect_general_data", "user__data_8py.html#adbaf29cac9edd842b77f435f2e44ae4b", null ]
];