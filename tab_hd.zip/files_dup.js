var files_dup =
[
    [ "filters", "dir_44e6750c3ba91f897faed10628147690.html", "dir_44e6750c3ba91f897faed10628147690" ],
    [ "handlers", "dir_97bbe734eff8d6674660850430e62f3c.html", "dir_97bbe734eff8d6674660850430e62f3c" ],
    [ "keyboards", "dir_0480ed5a272111c2455e9158e6b9c23d.html", "dir_0480ed5a272111c2455e9158e6b9c23d" ],
    [ "utility", "dir_64e73385a8b7738563c26ce10415b58d.html", "dir_64e73385a8b7738563c26ce10415b58d" ],
    [ "main.py", "main_8py.html", "main_8py" ],
    [ "settings.py", "settings_8py.html", "settings_8py" ]
];