var namespacecallbackdata =
[
    [ "ColInfo", "classcallbackdata_1_1_col_info.html", null ],
    [ "DocInfo", "classcallbackdata_1_1_doc_info.html", null ],
    [ "StatInfo", "classcallbackdata_1_1_stat_info.html", null ],
    [ "UserData", "classcallbackdata_1_1_user_data.html", null ]
];