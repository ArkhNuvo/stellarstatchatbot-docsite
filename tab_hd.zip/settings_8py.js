var settings_8py =
[
    [ "settings.Bots", "classsettings_1_1_bots.html", null ],
    [ "settings.Settings", "classsettings_1_1_settings.html", null ],
    [ "get_settings", "settings_8py.html#a0eba3d193ffb8089ea653eeab6a5d44f", null ],
    [ "settings", "settings_8py.html#a4742249a184e489a7b067fdcf88f301d", null ]
];