var basic_8py =
[
    [ "choose_file", "basic_8py.html#a8cfa9a69ddaeb63dc560c79b147f7858", null ],
    [ "get_csv", "basic_8py.html#a72eacffa7c0367cdbcc41df916db24d9", null ],
    [ "get_file_req", "basic_8py.html#a95379161e9c0cadec5e677781b2067e6", null ],
    [ "get_hello", "basic_8py.html#a22add420eb4b15f3464c2e6f5e433e14", null ],
    [ "get_help", "basic_8py.html#abc07ddeaf0149d8ba165fd16cfabf696", null ],
    [ "get_help_1", "basic_8py.html#a32c0a5b339979f152c3a9be01f439912", null ],
    [ "get_info", "basic_8py.html#a2d0182a2c8b65fac3d92eed39cfc886a", null ],
    [ "get_start", "basic_8py.html#a805fe9143a7f921d5d21eba1b47bcd80", null ]
];