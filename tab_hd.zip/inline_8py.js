var inline_8py =
[
    [ "get_file_menu", "inline_8py.html#a31bfe211f366c70c03e5ccda03249680", null ],
    [ "get_inline_doc_column_cat_keyboard", "inline_8py.html#a7c73f64177c85c0eda8f85823d7b4a85", null ],
    [ "get_inline_doc_column_num_keyboard", "inline_8py.html#a45a7de410f7c307660def14fc19a3a8c", null ],
    [ "get_inline_doc_columns_keyboard", "inline_8py.html#aa9f4761b1d8759d83b488b78021e897c", null ],
    [ "get_inline_doc_keyboard", "inline_8py.html#ac25cf17d561cb8347b10d2cf1cd5afb7", null ],
    [ "get_return_keyboard", "inline_8py.html#a1ca73e43f214d8409837f4b23a2d7761", null ]
];