var reply_8py =
[
    [ "get_reply_keyboard", "reply_8py.html#aa534cbff6086d69a1648fbb72549958e", null ]
];