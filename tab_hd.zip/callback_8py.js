var callback_8py =
[
    [ "choice_col_option", "callback_8py.html#a11165dcace205f02ddfdf0d34e3f946c", null ],
    [ "chose_file_from_storage", "callback_8py.html#a82257516ce42602115dc309fe791f234", null ],
    [ "select_col_option", "callback_8py.html#a223dab6a7496e7cfda8e0a88a1133a93", null ],
    [ "select_doc_option", "callback_8py.html#a48e1c0533a65f493fe2274202c64f4a0", null ]
];