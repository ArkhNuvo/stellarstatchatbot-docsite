var hierarchy =
[
    [ "settings.Bots", "classsettings_1_1_bots.html", null ],
    [ "prefix", null, [
      [ "callbackdata.ColInfo", "classcallbackdata_1_1_col_info.html", null ],
      [ "callbackdata.DocInfo", "classcallbackdata_1_1_doc_info.html", null ],
      [ "callbackdata.StatInfo", "classcallbackdata_1_1_stat_info.html", null ]
    ] ],
    [ "settings.Settings", "classsettings_1_1_settings.html", null ],
    [ "callbackdata.UserData", "classcallbackdata_1_1_user_data.html", null ],
    [ "BaseFilter", null, [
      [ "is_contact.IsTrueContact", "classis__contact_1_1_is_true_contact.html", null ]
    ] ],
    [ "CallbackData", null, [
      [ "callbackdata.ColInfo", "classcallbackdata_1_1_col_info.html", null ],
      [ "callbackdata.DocInfo", "classcallbackdata_1_1_doc_info.html", null ],
      [ "callbackdata.StatInfo", "classcallbackdata_1_1_stat_info.html", null ]
    ] ]
];