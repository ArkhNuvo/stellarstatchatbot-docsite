var namespacesettings =
[
    [ "Bots", "classsettings_1_1_bots.html", null ],
    [ "Settings", "classsettings_1_1_settings.html", null ],
    [ "get_settings", "namespacesettings.html#a0eba3d193ffb8089ea653eeab6a5d44f", null ]
];