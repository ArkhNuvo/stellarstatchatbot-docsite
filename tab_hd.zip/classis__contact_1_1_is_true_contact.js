var classis__contact_1_1_is_true_contact =
[
    [ "__call__", "classis__contact_1_1_is_true_contact.html#ad6c9595323362fd7b5fa2456869d6ab2", null ]
];